# -*- coding: utf-8 -*-
"""
Created on Sat Mar  4 09:32:35 2023

@author: jm.martinezc1
"""
import FuncionesN
#from Leertxt_caract import *
import numpy as np
import math
import Leertxt_caract
#from ayudaorden import *
import Auxvarios
vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto=Leertxt_caract.leertxt(Auxvarios.aordenar,Auxvarios.archivonum)

P=[]
P=lista0.copy()
P.remove(filas-1)
angulosmayuda=[]
angulosmayuda=angulito.copy()
j=0
V=[[0,0,0]]
hh=0
colltodos=[]
estoyenul=0

for ru in range(0, len(collnotches)):
    # compruebo que el inmediatamente siguiente no sea notche
    # posición

    posienpp=P.index(collnotches[ru])

    if ru == len(collnotches)-1:
        doblea = 1-1
        dobleb = posienpp - 1-1
        estoyenul = 1
    else:
        doblea = ru + 1
        dobleb = posienpp + 1
        estoyenul = 0 
    
    # compruebo que el siguiente no sea el consecutivo    

    if collnotches[doblea] == P[dobleb]:
        j += 1
        # exit for
        
    else:

        p1 = collnotches[ru]
        if estoyenul == 1:
            p2 = collnotches[0]
        else:
            p2 = collnotches[ru + 1] 

    if j == 0:
        collcreo = []
        # hago la figura
        posienpp=P.index(p1)
        inicio = posienpp
        posienpp=P.index(p2)
        fin = posienpp
        # si tiene que darle la vuelta al vector
        if inicio > fin:
            for xz in range(inicio,len(P)):
                collcreo.append(P[xz])
            for xz in range(0, fin + 1):
                collcreo.append(P[xz])
        else:
            for xz in range(inicio, fin + 1):
                collcreo.append(P[xz])

        # Evalúo los ángulos
        angulosmayuda,convexcont=FuncionesN.angulosfigura(collcreo,0,0,vertices,sentiang,opuesto)


        # evaluar si hay puntos dentro
        V[0][0] = p1
        V[0][2] = p2
        ira = 0
        ira=FuncionesN.puntosdentro(lista0,collcreo,0,0,filas,vertices,sentiang) #ARREGLAR

        # si hay puntos dentro pase a la siguiente iter

        if ira != 1:
            sali = 0
            for tu in range(len(angulosmayuda)):
                if angulosmayuda[tu] > 180:
                    sali = 1
                    break

            # si todo bien, corte
            if sali == 0:
                hh += 1

                #cortarr()##ARREGLAR
                P=FuncionesN.cortarr(collcreo, P)

                angulosmayuda,convexcont=FuncionesN.angulosfigura(P,0,0,vertices,sentiang,opuesto)
               #Agrego a la lista collcreo
               # En el momento que haga el corte agrego la lista
                colltodos.append(collcreo)
                #convexcont = 0

                for i in range(1, len(angulosmayuda)):
                    if angulosmayuda[i] > 180:
                        convexcont = 1
                convexcont=0
                # Si nuevadimen 3 ya pare
                nuevadimen=len(P)
                if nuevadimen == 3:
                    Peta = False
                    salir2 = 1
                    # break

                collpepe = []
                for i in range(1, len(P)):
                    creadopepe = 1
                    collpepe.append(P[i])               
               
            #si está bien la restante tiene que salirse                  
            if len(collnotches) == 2:
                ru += 1
    j = 0

if hh == 0:
# si no hubo ningún corte evalúe P igual
    angulosmayuda,convexcont=FuncionesN.angulosfigura(collcreo,0,0,vertices,sentiang,opuesto) #ARRREGLAR
    #except:
     #   print(doblea,dobleb)

colltodosc=[]
for i in range(0,len(colltodos)):
    colltodosc.append(colltodos[i])
    
    
