# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 18:22:32 2023

@author: jm.martinezc1
"""

import FuncionesN
#from Leertxt_caract import *
import numpy as np
import math
import sys
import Leertxt_caract
import Auxvarios
vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto=Leertxt_caract.leertxt(Auxvarios.aordenar,Auxvarios.archivonum)
from SCCortenuevon import *
from SCcombi import *

def AL1(movimiento):
    if convenoconve=="Es convexa":
        print("Es convexa")
        exit()
    else:
        #from SCCortenuevon import *
        parada=0
    
    #if creadopepe==1:
        #colltodos.append(colltodosa)
    
    #combino
    #from SCcombi import *
    
    #print("FIN")
    #print("PRUEBA", colltodos[0][7])
    
    matrizA=[]
    sumita=0
    #Area del polígono totoal
    

from SCcombi import *

#print("HOLAAA")