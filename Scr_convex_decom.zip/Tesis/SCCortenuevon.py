# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 17:45:26 2023

@author: jm.martinezc1
"""

import FuncionesN
#from Leertxt_caract import *
import numpy as np
import math
import sys
import Leertxt_caract
#from ayudaorden import *
import Auxvarios
vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto=Leertxt_caract.leertxt(Auxvarios.aordenar,Auxvarios.archivonum)

P=lista0.copy()
collpori=P.copy()
creadopepe=0
colltodos=[]
proce2=False
from SCNotch_a_notch import *
#Procedimiento de Notch a Notch:
noentra=0
if len(collnotches)>1:
    if len(colltodos)>=1:
        creadopepe=1
if creadopepe==1:
    colltodosa=colltodos.copy()
#Evalúo si aún hay notches
if any(valor>180 for valor in angulosmayuda):
    proce2=True
if proce2==True:
   #correr el otro algoritmo
    from SCAl1_largo import *
   
creadopepe=0
    
    
  