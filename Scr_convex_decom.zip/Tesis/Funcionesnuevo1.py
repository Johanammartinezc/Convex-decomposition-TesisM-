# -*- coding: utf-8 -*-
"""
Created on Fri Apr 14 11:33:12 2023

@author: jm.martinezc1
"""
import FuncionesN



def rectasdesde(poligonoaeva,vertices,posii,P):
    rectasprueba=[] #las 3 primeras son R1 las otras 3 son R2
    sentidosprueba=[]
    puntosprueba=[]
    for j in range(0,2):
        if posii<len(poligonoaeva)-1:
            if j==0:
                meme=-1
                ee=0
            else:
                meme=0
                ee=1
        else:
            if j==0:
                meme=-1
                ee=0
            else:
                meme=0
                ee=-posii
        ax=vertices[P[posii+meme]].x
        ay=vertices[P[posii+meme]].y
        bx=vertices[P[posii+ee]].x
        by=vertices[P[posii+ee]].y
        puntosprueba.append(P[posii+meme])
        puntosprueba.append(P[posii+ee])

        #registro ABC y sentidos
        A,B,C=FuncionesN.recta2(ax, ay, bx, by)
        rectasprueba.append(A)
        rectasprueba.append(B)
        rectasprueba.append(C)
        sentidorecta=FuncionesN.sentidor(ax,ay,bx,by,A,B)
        sentidosprueba.append(sentidorecta)
        
    

    return rectasprueba,sentidosprueba
        
        
def v1v2visi(desde,hasta,angulosmayuda,P,rectasprueba,vectorsentidos,posi,vertices):
 
    #Miro como da
    pevax=vertices[hasta].x
    pevay=vertices[hasta].y
    
    resultadi1=FuncionesN.puntoenrecta(rectasprueba[0],rectasprueba[1],rectasprueba[2],pevax,pevay,vectorsentidos[0])
    resultadi2=FuncionesN.puntoenrecta(rectasprueba[3],rectasprueba[4],rectasprueba[5],pevax,pevay,vectorsentidos[1])

    visi=0
    #Si es notch, si ambos están a la izquierda (por el orden), se muere,no es visible
    #Si no es notch, debe estar a la derecha en ambos para que entre
    if angulosmayuda[posi]>180:
        if resultadi1==resultadi2 and resultadi1=="IZQ":
            visi=1
        else:
            visi=0
    elif angulosmayuda[posi]<=180:
        if resultadi1==resultadi2 and resultadi1=="DERECHA":
            visi=0
        else:
            visi=1
    return visi
    
def colineales(desde,hasta,vertices,P,angulosmayuda):
    #1. hacer la recta que corresponde a los puntos y hallar los límites
    ax=vertices[desde].x
    ay=vertices[desde].y
    bx=vertices[hasta].x
    by=vertices[hasta].y
    #registro ABC,sentidos y min max
    A,B,C=FuncionesN.recta2(ax, ay, bx, by)
    sentidorecta=FuncionesN.sentidor(ax,ay,bx,by,A,B)
    minix=min(ax,bx)
    maxix=max(ax,bx)
    miniy=min(ay,by)
    maxiy=max(ay,ay)
    
    #2.Miro cuales puntos están en la recta dentro de los límites
    precta=[]
    for i in range(0,len(P)):
        pevax=vertices[P[i]].x
        pevay=vertices[P[i]].y
        
        if P[i]!=desde or P[i]!=hasta:
            resultadi=FuncionesN.puntoenrecta(A,B,C,pevax,pevay,sentidorecta)
            if resultadi=="EN RECTA" and pevax<=maxix and pevax>=minix and pevay<=maxiy and pevay<=maxiy:
                precta.append(P[i])
    return precta
             
def interseccion_conjuntos(Vi, Vj):
    # ordenamos los vértices de los conjuntos
    Vi = sorted(Vi)
    Vj = sorted(Vj)

    # realizamos la búsqueda binaria
    interseccion = []
    for vi in Vi:
        low = 0
        high = len(Vj) - 1
        while low <= high:
            mid = (low + high) // 2
            if Vj[mid] < vi:
                low = mid + 1
            elif vi < Vj[mid]:
                high = mid - 1
            else:
                interseccion.append(vi)
                break
    return interseccion     

def is_valid_subpolygon(vi, vj, vm,angulosmayuda,Poli,lista0,tuplasb,vertices,opuesto):
    """Determines if the triangle (i, k, j) forms a valid subpolygon"""
    # Implement your validation criteria here
    #El segundo ángulo debe ser menor a 180

    validtri=False
    tuplaim=(vi,vm)
    tuplamj=(vm,vj)
    tuplaij=(vi,vj)
    #posición para ver si es notch
    posiv=Poli.index(vm)
    #Hallar el ángulo formado
    V=[]
    V.append(vi),V.append(vm),V.append(vj)
    ircorte=0
    ircorte=FuncionesN.evaangvec2(V,vertices,Poli,opuesto)

    #condiciones del triángulo Timj: vivm y vjvm deben ser o del poli original o de otro corte. 

    if ircorte==0: 
        tuplax=buscar_tupla(tuplaij, tuplasb)
        if tuplax is not None:
            tuplax=buscar_tupla(tuplamj, tuplasb)
            if tuplax is not None or lista0.index(vm)+1==lista0.index(vj):
                tuplax=buscar_tupla(tuplaim, tuplasb)
                if tuplax is not None or lista0.index(vm)==lista0.index(vi)+1:
                    validtri=True   
    return validtri

def binary_searchjm(i, j,Poli,angulosmayuda,lista0,tuplas,vertices,opuesto,anguloseva):
    """Finds the smallest index k such that (i, k, j) forms a valid subpolygon"""
    low, high = i+1, j-1
    cont=0
    validtri=False
    mid=0

    while low <= high:
        mid = (low + high) // 2
        validtri=is_valid_subpolygon(Poli[i], Poli[j], Poli[mid],angulosmayuda,Poli,lista0,tuplas,vertices,opuesto)

        if validtri==True:
            return mid
        elif anguloseva[mid] < anguloseva[j]:
            cont=cont+1
            low = mid + 1
        else:
            low = mid + 1
    return None

def find_triangles(Poli,angulosmayuda,lista0,tuplasb,vertices,opuesto,angulito):
    """Finds all triangles that form valid subpolygons"""
    n = len(Poli)
    conti=0
    triangles = []
    copiapoli=Poli.copy()
    i=0
    paro=False
    anguloseva=[]

    for m in range(len(copiapoli)):
        posi=lista0.index(copiapoli[m])
        anguloseva.append(angulito[posi])

    j=len(copiapoli)-1
    m=0
    while m<j:
        m=m+1
        validtri=is_valid_subpolygon(Poli[i], Poli[j], Poli[m],angulosmayuda,Poli,lista0,tuplasb,vertices,opuesto)
        if validtri==True:
            triangles.append((copiapoli[i],copiapoli[m],copiapoli[j]))
            conti=conti+1
            continue
        else:
            continue
        
    return triangles,conti
    

def buscar_tupla(tupla_buscada, lista_tuplas):
    for tuplax in lista_tuplas:
        if tuplax[:2] == tupla_buscada:
            return tuplax
    return None


def lateralesbase(i1,i2,matriz,triangulo,entrada,inicial,final):
    devolucion=[]
    if entrada==0:
        llevo=matriz[i1][i2]
        a=triangulo+llevo[0]
        a = list(set(a))
        a.sort()
    else:
        prueba=matriz[i1][i2]
        llevo.append(prueba,llevo)
        a=devolucion[0]+llevo
    
    #pruebo la convexidad de a
    #FALTAAA-----
    
def convexvisi(poligono,vertices,angulosmayuda,tuplas,P):
    paila=0
    for i in range(0,len(poligono)):
        if paila==1:
            break
        desde=poligono[i]
        posi=P.index(desde)
        
        #creo matriz de rectas y sentidos
        rectasprueba1,sentidosprueba1=rectasdesde(poligono,vertices,posi,P)        

        #Evalúo los demás puntos desde ese
        for j in range(posi+2,len(poligono)):
            visi=0
            hasta=poligono[j]
            
            #1). V1 ve a V2
            visi=v1v2visi(desde,hasta,angulosmayuda,poligono,rectasprueba1,sentidosprueba1,posi,vertices)

            if visi==0:
            #2). V2 ve a v1
                posii=poligono.index(hasta)
                rectasprueba,sentidosprueba=rectasdesde(poligono,vertices,posii,P) 
                visi=v1v2visi(hasta,desde,angulosmayuda,poligono,rectasprueba,sentidosprueba,posii,vertices)

                if visi==0:
                    #3.)colineales
                    precta=colineales(desde,hasta,vertices,poligono,angulosmayuda)
                    #reviso que se pueda ver desde todos los puntos
                    for mk in range(0,len(precta)):
                        estoyen=precta[mk]
                        posi=poligono.index(estoyen)
                        rectasprueba,sentidosprueba=rectasdesde(estoyen,poligono,vertices,posi)  
                        
                        if desde!=poligono[posi-1]:
                            desdecol=estoyen
                            visi=v1v2visi(desdecol,desde,angulosmayuda,poligono,rectasprueba,sentidosprueba,posi,vertices)
                        elif hasta!=poligono[posi+1] and visi==0:
                            visi=v1v2visi(desdecol,hasta,angulosmayuda,poligono,rectasprueba,sentidosprueba,posi,vertices)
                        if visi==1:
                            #tiene que salirse y no seguir regorriendo
                            break

                    if visi==0:
                    #4). General
                        #líneas figura
                        mA,mB,mC,minx,maxx,miny,maxy=FuncionesN.rectaspoli(poligono,vertices)
                        ax=vertices[desde].x
                        ay=vertices[desde].y
                        bx=vertices[hasta].x
                        by=vertices[hasta].y
                        A,B,C=FuncionesN.recta2(ax, ay, bx, by)
                        minix=min(ax,bx)
                        maxix=max(ax,bx)
                        miniy=min(ay,by)
                        maxiy=max(ay,by)
                        #Recorro todas las rectas del polígono
                        for ho in range(0,len(mA)):
                            visi=0
                            xx,yy=FuncionesN.intersection(A, B, -C, mA[ho],mB[ho],-mC[ho])
                            #verifico que la intersección esté entre el min y max

                            tuplita=[(xx),(yy)]

                            if ho!=desde:
                                if xx is not None:
                                    if xx<=maxix and xx>=minix and yy<=maxiy and yy>=miniy:
                                        if xx<=maxx[ho] and xx>=minx[ho] and yy<=maxy[ho] and yy>=miny[ho]:
                                            if tuple(tuplita) not in tuplas:
                                                visi=1
                                                break
                                         
            
            if visi!=0:
                print("NO CONVEXA",desde,hasta,poligono)
                paila=1
                break
    return paila            
    




