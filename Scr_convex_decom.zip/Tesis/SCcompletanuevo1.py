# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 18:22:32 2023

@author: jm.martinezc1
"""

import FuncionesN
from Leertxt_caract import *
import numpy as np
import math
import sys

if convenoconve=="Es convexa":
    print("Es convexa")
    exit()
else:
    from SCCortenuevon import *
    parada=0

if creadopepe==1:
    colltodos.append(colltodosa)

#combino
from SCcombi import *

print("FIN")
#print("PRUEBA", colltodos[0][7])

matrizA=[]
sumita=0
#Area del polígono totoal

for aree in range(0,len(colltodos)):
    finalarea=Funciones.AREAA(aree, x, y, colltodos)
    matrizA.append(finalarea)

sumita=sum(matrizA)
#Área total
colltodos.append(lista0)
print(colltodos[-1])
areatotal=Funciones.AREAA(-1, x, y, colltodos)
if sumita==areatotal:
    print("FIN PERFECTO")
