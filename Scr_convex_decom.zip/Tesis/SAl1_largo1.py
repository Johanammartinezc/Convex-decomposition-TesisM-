# -*- coding: utf-8 -*-
"""
Created on Sat Mar  4 13:06:03 2023

@author: jm.martinezc1
"""
#OJO QUITAR LOS COMENTADOS DEL FROM ANTES DE CORRER

import Funciones2
from Leertxt_caract import *
import numpy as np
import math
import sys


# 1. Inicialización de P y variables.
creadopepe=0
if creadopepe == 0:
    P=lista0.copy()
corte=0
convexcont=0
Pinicial=0
Peta=True
mm=True
V=[[0,0,0]]
salir=0
cambiocam=0
saltese=0
antes=0
#hallarangulosp()
angulosmayuda,convexcont=Funciones2.angulosfigura(P,x,y)

# colltodos = Collection()
colltodos = []
collquedan = []
LL=0
while Peta:
    # Inicialización de contadores
    LUCKYS = 0
    mm = True
    salir = 0
    salir2 = 0
    irnocorte = 0
    saltese=False
    # Escoger ángulos y Evaluar vértices
    V[0][0],V[0][1],V[0][2],LL=Funciones2.escogervert(Pinicial,P,V)
    # Variable de ayuda para evitar evaluar la misma figura continuamente
    cambioV3 = 0 # 27/02
    print("VA 1")
    while mm==True:
        saltese=False
        ira=0
        lml=0
        #Debo sacar los ángulos de la figura restante
        angulosmayuda,convexcont=Funciones2.angulosfigura(P,x,y)

        Pinicial,mm,salir=Funciones2.evaang2(V[0][1],angulosmayuda,P,corte,Pinicial,mm,salir)

        if salir == 1:
            break
        
        Pinicial,cambiocam,irnocorte=Funciones2.evaant(V[0][2],P,angulosmayuda,V[0][1],Pinicial,cambiocam,irnocorte,lml,V[0][0])
     
        if irnocorte==1:
            antes=V[0][2]
            Pinicial,mm,V3=Funciones2.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
            V[0][2]=V3
            saltese=True



        if saltese==False: #para que haga el salto
            if cambiocam==1:
                break

            #evalúo puntos dentro del triángulo
            #evaluación del ángulo entre los vectores
            eeuu=0
            ircorte=Funciones2.evaangvec2(x,y,V)

            if ircorte==1:
                P, angulosmayuda,convexcont,mm,Peta=Funciones2.cortedelcorte(V[0][2],V[0][0],P,x,y,angulosmayuda,colltodos)
            eeuu=Funciones2.angulofinalini(V,x,y,P) #esto se puede mejorar

            #creo la figura
            figura=Funciones2.crearfigura(V[0][2],V[0][0],P,x,y)

            ira=Funciones2.puntosdentro(lista0,figura,x,y,filas)

            #Evalúo nuevamente el ángulo entre los vectores
            ircorte=Funciones2.evaangvec2(x,y,V)

            if ircorte==1:
                P, angulosmayuda,convexcont,mm,Peta=Funciones2.cortedelcorte(V[0][2],V[0][0],P,x,y,angulosmayuda,colltodos)
            ira=Funciones2.puntosdentro(lista0,figura,x,y,filas)

            # evaluación si el punto anterior al final fue >=180
            Pinicial,cambiocam,irnocorte=Funciones2.evaant(V[0][2],P,angulosmayuda,V[0][1],Pinicial,cambiocam,irnocorte,lml,V[0][0])  # ya hace el cambio

            if irnocorte == 1:
                antes=V[0][2]
                Pinicial,mm,V[0][2]=Funciones2.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
                saltese=True
            if saltese==False:     
               if cambiocam == 1:
                    break

                # evalúa si dentro de la figura creada hay notch
               if ira == 1:
                    pass
               else:
                    ira=Funciones2.puntosdentro(lista0,figura,x,y,filas)

               if eeuu == 1:
                # antes de irse a cortar evalúe la figura
                # tengo que evaluar que la figura cumple con lo de puntos dentro
                Pinicial,mm,V[0][2]=Funciones2.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
                saltese=True
                
            else:
                pass
        else:
            pass

        if ira == 1 or saltese==True: #############################
            # me devuelvo
            #GO TO ARREGLAR posienp(P, V[3])

            if saltese==False:
                Pinicial,mm,V[0][2]=Funciones2.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
                saltese=True
                if mm==False:
                    break ##para que no siga evaluando y se devuelva
            # agg
            else:
                #hallar posi porque esto se halla en nocorteee
                posienpp=P.index(V[0][2])

            if LUCKYS == 1:
                V[0][2] = V[0][2]
            else:
                posienpp=P.index(V[0][2])
                if posienpp == 0:
                    V[0][2] = P[-1]
                elif saltese==False:
                    V[0][2]  = P[posienpp - 1]
            # evalúo que no esté en el comienzo

            if V[0][2]  == V[0][1]:
                Pinicial += 1
                mm = False
            else:
                
                P,angulosmayuda,Pinicial,collp,salir2,mm=Funciones2.cortedelcorte(V[0][2],V[0][0],P,x,y,angulosmayuda,colltodos)

                nuevadimen=len(P)-1
                if salir2 == 1:
                    break
                if convexcont == 0:
                    Peta = False
                    break
                if nuevadimen == 3:

                    Peta = False
                    break
                Pinicial = 0

        else:
            LL += 1

            posienpp=P.index(V[0][1])
            cambioV3 += 1

            if cambioV3 == 1:
                anteriorV3 = V[0][1]
            # Si ya recorrí todos normales
            if posienpp + LL > len(P) - 1:
                if posienpp == 0:
                    LL = 0
                else:
                    # si el v(3) es el último
                    posienpp=P.index(V[0][2])
                    if posienpp == len(P) - 1:
                        LL = 0
                        posienpp=P.index(V[0][1])
                LL += 1
                anterior = V[0][2]
                if LL == 0:
                    V[0][2] = P[LL]
                else:
                    V[0][2] = P[LL - 1]
                # Sí al escoger V3 ya dio a vuelta cambie P inicial 27/02
                if V[0][2] == anteriorV3 and cambioV3 > 1:
                    # CAMBIE EL PUNTO INICIAL
                    pass
                # evaluar si ya está en el corte
                if V[0][2] == V[0][0] or V[0][2] == V[0][1]:
                    # irse a cortar
                    V[0][2] = anterior
                    #GOTO CORTEEEE
                    P,angulosmayuda,Pinicial,collp,salir2,mm=Funciones2.cortedelcorte(V[0][2],V[0][0],P,x,y,angulosmayuda,colltodos)
            else:
                # paso al siguiente
                print(V[0][2],Pinicial,"ayuda")
                posienpp=P.index(V[0][2])
                if posienpp == 0:
                    LL += 1
                    anterior = V[0][2]
                    V[0][2] = P[LL - 1]
                    # Sí al escoger V3 ya dio a vuelta cambie P inicial 27/02
                    if V[0][2] == anteriorV3 and cambioV3 > 1:
                        # CAMBIE EL PUNTO INICIAL
                        pass
                    # evaluar si ya está en el corte
                    if V[0][2] == V[0][0] or V[0][2] == V[0][1]:
                        # irse a cortar
                        V[0][1] = anterior
                        P,angulosmayuda,Pinicial,collp,salir2,mm=Funciones2.cortedelcorte(V[0][2],V[0][0],P,x,y,angulosmayuda,colltodos)
                else:
                    posienpp=P.index(V[0][1])
                    print(posienpp,LL,V[0][2],"cambio")    
                    V[0][2] = P[posienpp + LL+1]

#cuando acabe agregue P
P.remove(filas-1)
colltodos.append(P)
print("AL1 FINA")

            
        
            
