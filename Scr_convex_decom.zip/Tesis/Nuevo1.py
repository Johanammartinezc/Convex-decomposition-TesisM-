# -*- coding: utf-8 -*-
"""
Created on Thu Apr 13 15:00:34 2023

@author: jm.martinezc1

Este es basado en el algoritmo de Decomposing a Polygon into Simpler Components
"""
import Leertxt_caract
import Funcionesnuevo1
import FuncionesN
import matplotlib.pyplot as plt



#El sentido es 
aordenar=2
archivonum=1

#crear matriz vacía



#0. Información del polígono
vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto=Leertxt_caract.leertxt(aordenar,archivonum)
P=lista0.copy()
P.remove(filas-1) #antes 50
angulosmayuda=angulito


#graf
#Creo listas
x = x
y = y
# Crear un gráfico de dispersión
plt.figure(figsize=(10, 6))
plt.scatter(x, y)
plt.plot(x, y)

# Agregar etiquetas de eje y título
plt.xlabel('Eje X')
plt.ylabel('Eje Y')
plt.title('Gráfico de Dispersión 1.2')
lolo=list(range(0,filas-1))
for i in range(0,len(x)-1):
   plt.annotate(str(lolo[i]), xy=(x[i], y[i]), ha='center', va='bottom')

#1. Lista de Notches
#print(collnotches)
tuplas = list(zip(x, y))
tuplas.pop()

#2. Calculo la cantidad de puntos visibles
#matriz para guardar las visibilidades
n=len(P)
visibilidad=[[0 for j in range(n)] for i in range(n)]

#toda de 1 para que no se cuente él mismo como visible
for i in range(n):
    for j in range(n):
        if i==j+1 or i==j or j==i+1:
            visibilidad[i][j] = 0
        else:
            visibilidad[i][j] = 1

#matriz para guarddar cuales son
n=len(P)
visipuntos=[[0 for j in range(n)] for i in range(n)]

#toda de 1 para que no se cuente él mismo como visible
for i in range(n):
    for j in range(n):
        if i==j+1 or i==j:
            visipuntos[i][j] = j
            visipuntos[j][i] = i
        else:
            visipuntos[i][j] = 1
            visipuntos[j][i] = 1



#CICLO
desde=0
hasta=0
desdec=0
hastac=0
for i in range(0,len(P)):
    desde=P[i]
    posi=P.index(desde)
    #creo matriz de rectas y sentidos
    rectasprueba1,sentidosprueba1=Funcionesnuevo1.rectasdesde(P,vertices,posi,P)        

    #Evalúo los demás puntos desde ese
    for j in range(posi+2,len(P)):
        visi=0
        hasta=P[j]

        #1). V1 ve a V2
        visi=Funcionesnuevo1.v1v2visi(desde,hasta,angulosmayuda,P,rectasprueba1,sentidosprueba1,posi,vertices)

        if visi==0:
        #2). V2 ve a v1
            posii=P.index(hasta)
            rectasprueba,sentidosprueba=Funcionesnuevo1.rectasdesde(P,vertices,posii,P) 
            visi=Funcionesnuevo1.v1v2visi(hasta,desde,angulosmayuda,P,rectasprueba,sentidosprueba,posii,vertices)

            if visi==0:
                #3.)colineales
                precta=Funcionesnuevo1.colineales(desde,hasta,vertices,P,angulosmayuda)
                #reviso que se pueda ver desde todos los puntos
                if len(precta)!=0:
                    visi=1

                if visi==0:
                #4). General
                    #líneas figura
                    mA,mB,mC,minx,maxx,miny,maxy=FuncionesN.rectaspoli(P,vertices)
                    ax=vertices[desde].x
                    ay=vertices[desde].y
                    bx=vertices[hasta].x
                    by=vertices[hasta].y
                    A,B,C=FuncionesN.recta2(ax, ay, bx, by)
                    minix=min(ax,bx)
                    maxix=max(ax,bx)
                    miniy=min(ay,by)
                    maxiy=max(ay,by)
                    #Recorro todas las rectas del polígono
                    for ho in range(0,len(mA)):
                        visi=0
                        xx,yy=FuncionesN.intersection(A, B, -C, mA[ho],mB[ho],-mC[ho])
                        #verifico que la intersección esté entre el min y max
                        tuplita=[(xx),(yy)]
                        if ho!=desde:
                            if xx is not None:
                                if xx<=maxix and xx>=minix and yy<=maxiy and yy>=miniy:
                                    if xx<=maxx[ho] and xx>=minx[ho] and yy<=maxy[ho] and yy>=miny[ho]:
                                        if tuple(tuplita) not in tuplas:
                                            visi=1
                                            break

        visibilidad[i][j]=visi
        visibilidad[j][i]=visi
        if visi==0:
            if angulosmayuda[i]<=180 and vertices[j].reference==1: #estoy en un no notch y estoy evaluando un reference, registro
                visipuntos[i][j]=j
                visipuntos[j][i]=i
            elif angulosmayuda[i]<=180 and vertices[j].reference==0: #estoy en un no notch, evaluando a un no notch, no colocar nada
                pass
            elif angulosmayuda[i]<=180 and vertices[i].reference==0: #estoy en un no notch es es reference, evalúe todos
                visipuntos[i][j]=j
                visipuntos[j][i]=i          
            else:
                visipuntos[i][j]=j
                visipuntos[j][i]=i
        
#PASO 3. Dado que cada par de puntos visibles vivj son bases de subpolígonos válidos,
#hallar la medida COMO LA DIFERENCIA ENTRE LOS PUNTOS y ordenar
#Recorro la matriz visi y hago la lisa de pares ordenados
listiniciot=[]
listfint=[]
for i in range(0,len(P)):
    for j in range(0,len(P)):
        if visibilidad[i][j]==0 and i!=j and P[i]<P[j]:
            listiniciot.append(P[i])
            listfint.append(P[j])

#Hallo la dif puntos, teniendo en cuenta que 2 notch no sirven de poli

listdif=[]
listinicio=[]
listfin=[]
for i in range(0,len(listiniciot)):
    if 0<=listiniciot[i]<listfint[i]-1<=len(P)-1:
        if visibilidad[listiniciot[i]][listfint[i]]==0:
            if listiniciot[i]==0 or listfint[i]==P[-1]:
                listdif.append(listfint[i]-listiniciot[i])
                listinicio.append(listiniciot[i])
                listfin.append(listfint[i])
            elif angulosmayuda[listiniciot[i]]>=180 or angulosmayuda[listfint[i]]>=180:
                listdif.append(listfint[i]-listiniciot[i])
                listinicio.append(listiniciot[i])
                listfin.append(listfint[i])

tuplasordesde=sorted(list(zip(listinicio,listfin,listdif)), key=lambda x: x[0])  
  
tinifindist=sorted(list(zip(listinicio,listfin,listdif)), key=lambda x: x[2])

#PUNTO 4: hallo la intersección entre los conjuntos
#Armo los dos conjuntos a evaluar
basetri=[]

for i in range(0,len(tinifindist)):
    #compruebo si es un triángulo
    if tinifindist[i][2]==2:
        triangless=FuncionesN.crearfigura(tinifindist[i][1],tinifindist[i][0],P, x, y)
    else:
        Poli=FuncionesN.crearfigura(tinifindist[i][1],tinifindist[i][0], P, x, y)
        angulosmayuda,convexcont=FuncionesN.angulosfigura(Poli,x,y,vertices,sentiang,opuesto)
        triangless,conti=Funcionesnuevo1.find_triangles(Poli,angulosmayuda,lista0,tinifindist,vertices,opuesto,angulito)
    basetri.append(triangless)

#DP PROCEDURE-------------------------------------------------------------------------------

#0. Guardo en XR aquellos que sean triángulos, los demás debo procesarlos

n=len(P)
matrizxr=[[0 for j in range(n)] for i in range(n)]

for c in range(len(basetri)):    
    if tinifindist[c][2]==2:
        matrizxr[tinifindist[c][0]][tinifindist[c][1]]=basetri[c]
    else: #si no es un triángulo debo hacerle el procedimiento respectivo
        numtri=len(basetri[c])
        for k in range(numtri):
            #procedimiento
            i=basetri[c][k][0]
            m=basetri[c][k][1]
            j=basetri[c][k][2]
            
            entrada=0
            if m!=i+1:
                entrada=1
                #ACTIVAR LA FUNCIÓN
            
            if j!=m+1:
                pass
                #ACTIVAR LA FUNCIÓN
                
            #if matrizxr[i][j] is None:
                #matrizxr[i][j]=devolucion
            #elif matrizxr[i][j]>devolucion:
                #matrizxr[i][j]=devolucion
            
         
            poligono=FuncionesN.crearfigura(49,0,P, x, y)
            angulosmayuda,convexcont=FuncionesN.angulosfigura(poligono,x,y,vertices,sentiang,opuesto)
            paila=Funcionesnuevo1.convexvisi(poligono, vertices, angulosmayuda, tuplas,P)
            print(paila)
            exit()

 
print("TERMINE")
                            
                
        