# -*- coding: utf-8 -*-
"""
Created on Mon Mar 13 11:57:39 2023

@author: jm.martinezc1
"""

global aordenar,archivonum


aordenar=2
archivonum=2