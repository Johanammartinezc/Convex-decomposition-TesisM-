# -*- coding: utf-8 -*-
"""
Created on Sun Mar 26 18:12:54 2023

@author: jm.martinezc1
"""
import FuncionesN
#from Leertxt_caract import *
import numpy as np
import math
import sys
import Leertxt_caract
#from ayudaorden import *
import Auxvarios
import SCcombi
vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto=Leertxt_caract.leertxt(Auxvarios.aordenar,Auxvarios.archivonum)


from Svecinos import*

colltodos=SCcombi.colltodoscombi
P=SCcombi.P


if len(P)==len(lista0) or len(P)==0:
    P=lista0.copy()
    P.remove(filas-1) #antes 50
    colltodos = []
else:
    colltodos=[]
    for i in range(0,len(SCcombi.colltodoscombi)):
        colltodos.append(SCcombi.colltodoscombi[i])

corte=0
convexcont=0
Pinicial=0
Peta=True
mm=True
V=[[0,0,0]]
salir=0
cambiocam=0
saltese=0


angulosmayuda,convexcont=FuncionesN.angulosfigura(P,0,0,vertices,sentiang)
# colltodos = Collection()

collquedan = []
LL=0
entradaa=0
while Peta:
    # Inicialización de contadores
    LUCKYS = 0
    mm = True
    salir = 0
    salir2 = 0
    irnocorte = 0
    saltese=False
    # Escoger ángulos y Evaluar vértices
    if len(P)==2:
        break
    V[0][0],V[0][1],V[0][2],LL=FuncionesN.escogervert(Pinicial,P,V)
    
    # Variable de ayuda para evitar evaluar la misma figura continuamente
    cambioV3 = 0 # 27/02
    entradaa=entradaa+1
    print("entrada",entradaa)

    while mm==True:
        saltese=False
        ira=0
        lml=0
        #Debo sacar los ángulos de la figura restante
        angulosmayuda,convexcont=FuncionesN.angulosfigura(P,0,0,vertices,sentiang)
        #evalúo en ángulo 2 de esa figura
        Pinicial,mm,salir=FuncionesN.evaang2(V[0][1],angulosmayuda,P,corte,Pinicial,mm,salir)

        if salir == 1:
            break
        Pinicial,cambiocam,irnocorte=FuncionesN.evaant(V[0][2],P,angulosmayuda,V[0][1],Pinicial,cambiocam,irnocorte,lml,V[0][0])

        if irnocorte==1:
            antes=V[0][2]
            Pinicial,mm,V3=FuncionesN.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
            V[0][2]=V3
            saltese=True

        if saltese==False: #para que haga el salto
            if cambiocam==1:
                break
            #evalúo puntos dentro del triángulo
            #evaluación del ángulo entre los vectores
            eeuu=0
            ircorte=FuncionesN.evaangvec2(0,0,V,vertices)

            if ircorte==1:
                P, angulosmayuda,convexcont,mm,Peta=FuncionesN.cortedelcorte(V[0][2],V[0][0],P,0,0,angulosmayuda,colltodos,vertices,sentiang)
            eeuu=FuncionesN.angulofinalini(V,0,0,P,vertices,opuesto) #esto se puede mejorar

            #creo la figura
            figura=FuncionesN.crearfigura(V[0][2],V[0][0],P,x,y)

            ira=FuncionesN.puntosdentro(lista0,figura,0,0,filas,vertices,sentiang)

            #Evalúo nuevamente el ángulo entre los vectores
            ircorte=FuncionesN.evaangvec2(0,0,V,vertices)

            if ircorte==1:
                P, angulosmayuda,convexcont,mm,Peta=FuncionesN.cortedelcorte(V[0][2],V[0][0],P,0,0,angulosmayuda,colltodos,vertices,Peta,Sentiang)
            ira=FuncionesN.puntosdentro(lista0,figura,0,0,filas,vertices,sentiang)

            # evaluación si el punto anterior al final fue >=180
            Pinicial,cambiocam,irnocorte=FuncionesN.evaant(V[0][2],P,angulosmayuda,V[0][1],Pinicial,cambiocam,irnocorte,lml,V[0][0])  # ya hace el cambio

            if irnocorte == 1:
                Pinicial,mm,V[0][2]=FuncionesN.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
                saltese=True
            if saltese==False:     
               if cambiocam == 1:
                    break

                # evalúa si dentro de la figura creada hay notch
               if ira == 1:
                    pass
               else:
                    ira=FuncionesN.puntosdentro(lista0,figura,0,0,filas,vertices,sentiang)

               if eeuu == 1:
                # antes de irse a cortar evalúe la figura
                # tengo que evaluar que la figura cumple con lo de puntos dentro
                Pinicial,mm,V[0][2]=FuncionesN.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
                saltese=True
                
            else:
                pass
        else:
            pass

        if ira == 1 or saltese==True: #############################
            # me devuelvo
            #GO TO ARREGLAR posienp(P, V[3])

            if saltese==False:
                Pinicial,mm,V[0][2]=FuncionesN.nocorteee(P,V[0][2],Pinicial,V,LUCKYS)
                saltese=True
                if mm==False:
                    break ##para que no siga evaluando y se devuelva
            # agg
            else:
                #hallar posi porque esto se halla en nocorteee
                posienpp=P.index(V[0][2])

            if LUCKYS == 1:
                V[0][2] = V[0][2]
            else:
                posienpp=P.index(V[0][2])
                if posienpp == 0:
                    V[0][2] = P[-1]
                elif saltese==False:
                    V[0][2]  = P[posienpp - 1]
            # evalúo que no esté en el comienzo

            if V[0][2]  == V[0][1]:
                Pinicial += 1
                mm = False
            else:
                
                P,angulosmayuda,Pinicial,collp,salir2,mm,Peta=FuncionesN.cortedelcorte(V[0][2],V[0][0],P,0,0,angulosmayuda,colltodos,vertices,Peta,sentiang)

                nuevadimen=len(P)

                if salir2 == 1:
                    break
                if convexcont == 0:
                    Peta = False
                    break
                if nuevadimen == 3:
                    Peta = False
                    break
                Pinicial = 0

        else:
            LL += 1

            posienpp=P.index(V[0][1])
            cambioV3 += 1

            if cambioV3 == 1:
                anteriorV3 = V[0][2]
            # Si ya recorrí todos normales

            if posienpp + LL > len(P) - 2:
                if posienpp == 0:
                    LL = 0
                else:
                    # si el v(3) es el último
                    posienpp=P.index(V[0][2])
                    if posienpp == len(P) - 1:
                        LL = 0
                        posienpp=P.index(V[0][1])
                LL += 1
                anterior = V[0][2]
                if LL == 0:
                    V[0][2] = P[LL]
                else:
                    V[0][2] = P[LL - 1]
                # Sí al escoger V3 ya dio a vuelta cambie P inicial 27/02
                if V[0][2] == anteriorV3 and cambioV3 > 1:
                    # CAMBIE EL PUNTO INICIAL
                    pass
                # evaluar si ya está en el corte
                if V[0][2] == V[0][0] or V[0][2] == V[0][1]:
                    # irse a cortar
                    V[0][2] = anterior
                    #GOTO CORTEEEE
                    P,angulosmayuda,Pinicial,collp,salir2,mm,Peta=FuncionesN.cortedelcorte(V[0][2],V[0][0],P,0,0,angulosmayuda,colltodos,vertices,Peta,sentiang)
                                                                                     
            else:
                # paso al siguiente
                #print(V[0][2],Pinicial,"ayuda")
                posienpp=P.index(V[0][2])
                if posienpp == 0:
                    LL += 1
                    anterior = V[0][2]
                    V[0][2] = P[LL - 1]
                    # Sí al escoger V3 ya dio a vuelta cambie P inicial 27/02
                    if V[0][2] == anteriorV3 and cambioV3 > 1:
                        # CAMBIE EL PUNTO INICIAL
                        pass
                    # evaluar si ya está en el corte
                    if V[0][2] == V[0][0] or V[0][2] == V[0][1]:
                        # irse a cortar
                        V[0][1] = anterior
                        P,angulosmayuda,Pinicial,collp,salir2,mm=FuncionesN.cortedelcorte(V[0][2],V[0][0],P,0,0,angulosmayuda,colltodos,vertices,sentiang)
                else:
                    
                    posienpp=P.index(V[0][1])
                    #print(posienpp,LL,V[0][0],V[0][1],V[0][2],"cambio",P)
                    V[0][2] = P[posienpp + LL+1]


#cuando acabe agregue P

colltodos.append(P)


#COMBINAR
# número de polígonos
numpoli = len(colltodos)
# arreglo que guarda la lista de números de polígonos en cuestión para el proceso de combinación
collpoli = []
Salidita=0
# contador
cortaditas = 0
contadorcito=0
qq=0
ccc=0
ere=0
qui=0
quitar=0
paila=0
puedo=True
endd=0
lenant=0
numpoliantes=0
anteriorr=0
while puedo==True:
    numpoli = len(colltodos)
    endd=endd+1
    #print("vuelta",len(colltodos),cortaditas)
    contadorcito=0
    for cott in range(0, numpoli-1):
        if cott>numpoli-1:
            break
        numeleini = len(colltodos[cott])
        
        for i in range(0, numeleini):
            # escojo el par de elementos a evaluar
            collpoli = []
            parrx,parry,ultimaiter=Funciones.elegirxy(numeleini,colltodos,cott,i)
            

            
            # evaluo la combinación en los polígonos, en qué polígonos está
            contadorr = 0
    
            for k in range(0, numpoli):
                numele = len(colltodos[k])
                collpoli,contadorr,rompe=Funciones.evaluarenpoli(numele,cott,colltodos,parrx,parry,k,collpoli,contadorr)
            

            # antes de pasar al siguiente corte debo evaluar si fue cont>1
    
            if contadorr >= 1:
                collpoli.append(cott)
                # 1. Definir las rectas
                
                qq=0
                Poli1,quitar,paila,qq=Funciones.definirrectas(collpoli,parrx,parry,colltodos,x,y,qq,quitar,paila,opuesto)
                # 2. Evaluar si los puntos del otro polígono están a la derecha o izquierda
                # 3. Si no hay derechas quito la línea

                if quitar == 1:
                    # 4. Redimensionar cosas, nuevos polígonos juntos
                    paradira = 1
                    if qq >= 4:
                        # contador para saber cuántas veces cortó
                        contadorcito=contadorcito+1
                        cortaditas = cortaditas + 1

                        # crea el nuevo polígono
                        colltodos,collpoli,collnuevo=Funciones.nuevopoli(collpoli,colltodos,ccc,ere)

                        # quita los polígonos que se combinan y agg el nuevo
                        #if cott==1 and parrx==0 and parry==8:
                         #   print("AQUI",contadorr,quitar,Poli1,qq,collnuevo)
                          #  exit()
                        #colltodos=Funciones.quitaryponer(collpoli,colltodos,collnuevo)
                        numpoli = len(colltodos)
                        break
                    else:
                        pass
                else:
                    paradira = 0
            else:
                contadorr=0
            if ultimaiter == 1:
                contadorr = 0
                # Pase al siguiente poli
                Salidita=0
                if cott == numpoli-1 and ultimaiter == 1 and cortaditas == 0:
                    # PARE TODO
                    numpoli = len(colltodos)
                    Salidita = 1
                    break
                else:
                    continue
        qui=1
        ultimaiter = 0
        numpoliant = numpoli-1
        numpoliantes=numpoli
        numpoli = len(colltodos)
        

        # si cambia coll debe empezar a evaluar nuevamente todos los polígonos
        if numpoliant != numpoli:
            cott = 0
            cortaditas = 0
        
        if Salidita == 1:
            puedo=True
            break
            

    if contadorcito==0:
        puedo=False
        Salidita==1      

        
if Salidita == 1:
    print("EXITO")
    pass



print("YA POR FIN")