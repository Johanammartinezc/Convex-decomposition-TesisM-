# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 16:00:24 2023

@author: jm.martinezc1
"""
import pandas as pd
import numpy as np
import Funciones
import FuncionesN
#global colltodos
def leertxt(orden,archivonum):
    #Sentidos cambian
    if orden==1:
        sentiang="IZQ"
        opuesto="DERECHA"
    else:
        sentiang="DERECHA"
        opuesto="IZQ"
    ruta=r"C:\Users\jm.martinezc1\Desktop\Tesis\Figuras de prueba\50\P50-"
    texx=str(archivonum)
    rutacompleta=ruta+texx+".txt"
    df=pd.read_csv(rutacompleta,'\t',header=None)
    print(df.head())
    #IMPORTACIONES
        
    #VARIABLE
    x=[]
    y=[]
    vectorA=[]
    vectorB=[]
    vectorC=[]
    xori=[]
    yori=[]
    n=[]
    vectorAn=[]
    vectorBn=[]
    vectorCn=[]
    vectorXorin=[]
    vectorYorin=[]
    vectorSR=[]
    vectorposip=[]
    angulito=[]
    coefxA=[]
    coefyB=[]
    coefC=[]
    lista0=[]
    collnotches=[]
    nk=0
    
    #0. Hallo el número de vértices.
    
    filas=len(df)

    #1. Creo un ciclo para guardar la información en la clase
    #ESTE CICLO DEPENDE DE COMO QUIERA RECORRER LA FIGURA
    for i in range(0,filas):
        x.append(df.loc[i,0])
        y.append(df.loc[i,1])
    

    #si no está el primero de último lo agg
    #Los guardo como tuplas
    primerp=(x[0],y[0])
    ultimop=(x[-1],y[-1])
    if primerp!=ultimop:
        x.append(x[0])
        y.append(y[0])
        filas=filas+1
    
    if orden==2:
        x=list(reversed(x))
        y=list(reversed(y)) 
    

    #2. ciclo para hallar ABC
    for i in range(0,filas-1):
        ax=x[i]
        ay=y[i]
        bx=x[i+1]
        by=y[i+1]
        #llamar a la función recta2
        A,B,C=Funciones.recta2(ax,ay,bx,by)
        vectorA.append(A)
        vectorB.append(B)
        vectorC.append(C)
        
    
    #3. Normalizo para poder utilizar la función de tetha normal
    for i in range(0,filas-1):
        xori.append(x[i+1]-x[i])
        yori.append(y[i+1]-y[i])
        n.append(np.sqrt((xori[i]**2)+(yori[i]**2)))
        normita=n[i]
        #llamar a la función normalizarABC
        An,Bn,Cn=Funciones.normalizarABC(0,0,xori[i],y[i],normita)
        vectorAn.append(An)
        vectorBn.append(Bn)
        vectorCn.append(Cn)
        #llamo a la funcioón normalizarxori
        Xorin,Yorin=Funciones.normalizarxori(0,0,xori[i],yori[i],normita)
        vectorXorin.append(Xorin)
        vectorYorin.append(Yorin)
    
    #4 Hallo el sentido de las rectas
    for i in range(0,filas-1):
        #llame  a la función sentidor (toca arreglar, con las pendientes es más fácil)
        srr=Funciones.sentidor(x[i], y[i], x[i+1], y[i+1], vectorA[i], vectorB[i])
        vectorSR.append(srr)
    
    
    #5. Evalúo la posición del punto
    for i in range(0,filas-1):
        if i==0:
            coefxA.append(vectorA[-1])
            coefyB.append(vectorB[-1])
            coefC.append(vectorC[-1])
            pevax=x[1]
            pevay=y[1]
        elif (i>=1) and (i<=filas-2):
            coefxA.append(vectorA[i-1])
            coefyB.append(vectorB[i-1])
            coefC.append(vectorC[i-1])
            pevax=x[i+1]
            pevay=y[i+1]
        else:
            coefxA.append(vectorA[i-1])
            coefyB.append(vectorB[i-1])
            coefC.append(vectorC[i-1])
            pevax=x[0]
            pevay=y[0]
        #call puntoenrecta
        resultadi=FuncionesN.puntoenrecta(coefxA[i], coefyB[i], coefC[i], pevax, pevay,vectorSR[i-1])
        vectorposip.append(resultadi)

    #6. Escoger el ángulo#######################
    for i in range(0,filas-1):
        if i==0:
            coorx1=vectorXorin[-1]
            coory1=vectorYorin[-1]
            coorx2=vectorXorin[0]
            coory2=vectorYorin[0]
        else:
            coorx1=vectorXorin[i-1]
            coory1=vectorYorin[i-1]
            coorx2=vectorXorin[i]
            coory2=vectorYorin[i]       
        #call angulo2
        angulotetha=Funciones.angulo2(coorx1, coory1, coorx2, coory2)
        if i==0:
            sentirecta=vectorSR[-1]
        else:
            sentirecta=vectorSR[i-1]
        
        if vectorposip[i]==sentiang:#"IZQ
            if sentirecta=="NORTE" or sentirecta=="SUR" or sentirecta=="ESTE" or sentirecta=="OESTE":
                angulito.append(180-angulotetha)
            else:
                angulito.append(180-angulotetha)
        else:
            angulito.append(180+angulotetha)
    
    
    #7 evalúo convexidad
    conta=0
    notches=[]
    for i in range(0,filas-1):
        if angulito[i]>=180 or i==0 or i==filas-2:
            if angulito[i]>=180:
                conta=conta+1
            collnotches.append(i)
            notches.append(1)
        else:
            notches.append(0)
    if conta>0:
        convenoconve="No es convexa"
    else:
        convenoconve="Es convexa"
       
    
    #Creación de lista original
    for i in range(0,filas):##
        lista0.append(i)
            
    #GUARDAR LAS COSAS EN CLASES.-----------------------------------
    #creo la clase
    class vertice:
        def __init__(self, x,y,angulo,notch,vecinosnum,vecinos,reference,visibilidad): #num vecinos y área estimada
            self.x = x
            self.y = y
            self.angulo = angulo
            self.notch = notch
            self.vecinosnum=vecinosnum
            self.vecinos=vecinos
            self.reference=reference #en la primera iter son los notches
            self.visibilidad = visibilidad
            
        
            
    # Crear cada instancia de cada vértice
    #lista para determinar los vecinos iniciales
    P=lista0.copy()
    listadeks,conteos=Funciones.kvecinos(angulito,P) #vecinos
    print(conteos,"conteo")
    vertices=[]
    
    #lista de references
    
    
    for i in range(0,filas-1):##
        verticeagg = vertice(x[i],y[i],angulito[i],notches[i],conteos[i],listadeks[i],notches[i],1)
        vertices.append(verticeagg)
    P=[]
    
    
    
    #Clase para las rectas
    class lineas:
        def __init__(self,A,B,C,xmin,xmax,ymin,ymax):
            self.A = A
            self.B = B
            self.C = C
            self.xmin = xmin
            self.xmax = xmax
            self.ymin = ymin
            self.ymax = ymax
    
    #creo las instancias
    listalineas=[]
    for i in range(0,filas-1):
        if i==filas-1:
            ax=x[-1]
            ay=y[-1]
            bx=x[1]
            by=y[1]
        else:
            ax=x[i]
            ay=y[i]
            bx=x[i+1]
            by=y[i+1]
        A,B,C=Funciones.recta2(ax, ay, bx, by)
        #miro don y rango
        xmin=min(ax,bx)
        xmax=max(ax,bx)
        ymin=min(ay,by)
        ymax=min(ay,by)
        linea=lineas(A,B,C,xmin,xmax,ymin,ymax)
        listalineas.append(linea)


    return vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto


#leertxt(2)       