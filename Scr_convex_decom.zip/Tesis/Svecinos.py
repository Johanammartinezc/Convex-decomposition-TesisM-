# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 17:07:29 2023

@author: jm.martinezc1
"""
import Leertxt_caract
import FuncionesN
import Funciones
import Auxvarios
import SCcombi

vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto=Leertxt_caract.leertxt(Auxvarios.aordenar,Auxvarios.archivonum)

#saco el máximo de los vecinos
P=lista0.copy()
P.remove(len(lista0)-1)
listaveci=[]
for i in range(0,len(P)-1):
    listaveci.append(vertices[i].vecinosnum)
    
pos_max = listaveci.index(max(listaveci))

#Ese es el Pinicial
entrag=1
Pinicial=P[pos_max]
#Final
Pfinal=P[P.index(vertices[P[pos_max]].vecinos[-1])+1]
Peta=True
colltodos=[]
entrad=0
Pfinal=P[P.index(vertices[Pinicial].vecinos[-1])+1]
clistaveci=listaveci.copy()
clistaveciv=[]
clistavecinum=[]
entrac=0
escoger=True
entrax=0
convexcont=0

while Peta==True:
    entrad=entrad+1

    #Escojo el mayor de la lista si es necesario
    if escoger==True:
        maximo=max(clistaveci)

        #si el máximo es 0 es porque ya acabó, entonces halle los vecinos de la restante
        
        #bloquear esto si no está el de conve conve
        if maximo==0:
            break
        """
        if maximo==0 and entrax==0:
            entrax=entrax+1
            clistaveci=[]
            angulosmayuda,convexcont=FuncionesN.angulosfigura(P,x,y,vertices,sentiang)
            for j in range(0,filas-1):
                if j in P:
                    if angulosmayuda[P.index(j)]<=180:
                        clistaveciv,clistavecinum=Funciones.kvecinospunto(angulosmayuda, P, j)
                        vertices[lista0.index(j)].vecinos=clistaveciv
                        vertices[lista0.index(j)].vecinosnum=clistavecinum
                    else:
                        vertices[lista0.index(j)].vecinos=0
                        vertices[lista0.index(j)].vecinosnum=0
                else:
                    vertices[lista0.index(j)].vecinos=0
                    vertices[lista0.index(j)].vecinosnum=0
            for i in range(0,len(lista0)-2):
                clistaveci.append(vertices[i].vecinosnum)

            continue
        elif maximo==0 and entrax==1:    
            break
        """
        indi=clistaveci.index(maximo)
        Pinicial=lista0[indi]

        if Pinicial not in P:
            clistaveci[lista0.index(Pinicial)]=0
            continue
        
        #nuevo

        if vertices[Pinicial].vecinos[-1] not in P:
            clistaveci[lista0.index(Pinicial)]=0
            continue

        if P.index(vertices[Pinicial].vecinos[-1])+1<len(P):
            Pfinal=P[P.index(vertices[Pinicial].vecinos[-1])+1]
        else:
            Pfinal=P[0]

        if Pinicial==Pfinal:
            Pfinal=P[P.index(vertices[Pinicial].vecinos[-1])-1]

    #Evalúo si hay puntos dentro

    collp=FuncionesN.crearfigura(Pfinal,Pinicial,P,x,y)

    angulosmayuda,convexcont=FuncionesN.angulosfigura(collp,x,y,vertices,sentiang)


    if convexcont==0:
        ira=0
        ira=FuncionesN.puntosdentro(lista0,collp,x,y,filas,vertices,sentiang)

    else:
        ira=1
    #ira=FuncionesN.minmaxpuntosdentro(collp, vertices, lista0, filas, ira, sentiang)

    if ira==0:

        #evalúe los ángulos de la figura creada
        convexcont=0
        angulosmayuda,convexcont=FuncionesN.angulosfigura(collp,x,y,vertices,sentiang)

        if convexcont==1:
            #si es no convexa, recortese
            continue
            entrag=entrag+1
            #cambie Pinicial por el máximo
            #si se da que el mismo es el del comienzo
            escoger=True
            vertices[lista0.index(Pinicial)].vecinos=0
            vertices[lista0.index(Pinicial)].vecinosnum=0
            clistaveci=[]
            for i in range(0,len(lista0)-2):
                clistaveci.append(vertices[i].vecinosnum)
            continue
            
        else:
            #cortar si la figura restante tiene más de 3 vértices:
            if len(P)>=3:
                entrac=entrac+1
                P,angulosmayuda,Piniciall,collp,salir2,mm,Peta=FuncionesN.cortedelcorte(Pfinal,Pinicial,P,x,y,angulosmayuda,collp,vertices,Peta,sentiang)
                colltodos.append(collp)
                #Actualizar la lista de vecinos
                clistaveciv,clistavecinum=Funciones.kvecinospunto(angulosmayuda, P, collp[0])
                vertices[lista0.index(Pinicial)].vecinos=clistaveciv
                vertices[lista0.index(Pinicial)].vecinosnum=clistavecinum

                #si el final es notch, tiene que hallar los vecinos
                if angulosmayuda[P.index(Pfinal)]>180:
                    clistaveciv,clistavecinum=Funciones.kvecinospunto(angulosmayuda, P, collp[-1])
                    vertices[lista0.index(Pfinal)].vecinos=clistaveciv
                    vertices[lista0.index(Pfinal)].vecinosnum=clistavecinum
                clistaveci=[]
                #sobreescribo la lista correspondiente
                for i in range(0,len(lista0)-2):
                    clistaveci.append(vertices[i].vecinosnum)
                #después, debo escoger Pinicial y Pfinal otra vez, el máx
                escoger=True
                continue
            else:
                Peta=False
    else:
        #no puede recortarle más de 2
        if len(collp)>=4:
            Pfinal=P[P.index(Pfinal)-1]
            escoger=False
        else:
            entrag=entrag+1
            #cambie Pinicial por el máximo
            #si se da que el mismo es el del comienzo
            escoger=True
            vertices[lista0.index(Pinicial)].vecinos=0
            vertices[lista0.index(Pinicial)].vecinosnum=0
            clistaveci=[]
            for i in range(0,len(lista0)-2):
                clistaveci.append(vertices[i].vecinosnum)
            continue



colltodosc=colltodos

#from AL1 import*
angulosmayuda,convexcont=FuncionesN.angulosfigura(P,x,y,vertices,sentiang)


from SCcombi import *


print("FIN REVISAR")
        
        





