# -*- coding: utf-8 -*-
"""
Created on Sun Mar  5 10:36:28 2023

@author: jm.martinezc1
"""
#OJO QUITAR LOS COMENTADOS DEL FROM ANTES DE CORRER

import FuncionesN
from Leertxt_caract import *
import numpy as np
import math
import sys

#ACTIVAR O DESACTIVAR DE ACUERDO AL PROCESO QUE SE QUIERA------------------
from SCAl1_largo import *
#from Svecinos import *




# número de polígonos
numpoli = len(colltodos)
# arreglo que guarda la lista de números de polígonos en cuestión para el proceso de combinación
collpoli = []
Salidita=0
# contador
cortaditas = 0
contadorcito=0
qq=0
ccc=0
ere=0
qui=0
quitar=0
paila=0
puedo=True
endd=0
lenant=0
numpoliantes=0
anteriorr=0
while puedo==True:
    numpoli = len(colltodos)
    endd=endd+1
    #print("vuelta",len(colltodos),cortaditas)
    contadorcito=0
    for cott in range(0, numpoli-1):
        if cott>numpoli-1:
            break
        numeleini = len(colltodos[cott])
        
        for i in range(0, numeleini):
            # escojo el par de elementos a evaluar
            collpoli = []
            parrx,parry,ultimaiter=Funciones.elegirxy(numeleini,colltodos,cott,i)
            

            
            # evaluo la combinación en los polígonos, en qué polígonos está
            contadorr = 0
    
            for k in range(0, numpoli):
                numele = len(colltodos[k])
                collpoli,contadorr,rompe=Funciones.evaluarenpoli(numele,cott,colltodos,parrx,parry,k,collpoli,contadorr)
            

            # antes de pasar al siguiente corte debo evaluar si fue cont>1
    
            if contadorr >= 1:
                collpoli.append(cott)
                # 1. Definir las rectas
                
                qq=0
                Poli1,quitar,paila,qq=Funciones.definirrectas(collpoli,parrx,parry,colltodos,x,y,qq,quitar,paila,opuesto)
                # 2. Evaluar si los puntos del otro polígono están a la derecha o izquierda
                # 3. Si no hay derechas quito la línea

                if quitar == 1:
                    # 4. Redimensionar cosas, nuevos polígonos juntos
                    paradira = 1
                    if qq >= 4:
                        # contador para saber cuántas veces cortó
                        contadorcito=contadorcito+1
                        cortaditas = cortaditas + 1

                        # crea el nuevo polígono
                        colltodos,collpoli,collnuevo=Funciones.nuevopoli(collpoli,colltodos,ccc,ere)

                        # quita los polígonos que se combinan y agg el nuevo
                        #if cott==1 and parrx==0 and parry==8:
                         #   print("AQUI",contadorr,quitar,Poli1,qq,collnuevo)
                          #  exit()
                        #colltodos=Funciones.quitaryponer(collpoli,colltodos,collnuevo)
                        numpoli = len(colltodos)
                        break
                    else:
                        pass
                else:
                    paradira = 0
            else:
                contadorr=0
            if ultimaiter == 1:
                contadorr = 0
                # Pase al siguiente poli
                Salidita=0
                if cott == numpoli-1 and ultimaiter == 1 and cortaditas == 0:
                    # PARE TODO
                    numpoli = len(colltodos)
                    Salidita = 1
                    break
                else:
                    continue
        qui=1
        ultimaiter = 0
        numpoliant = numpoli-1
        numpoliantes=numpoli
        numpoli = len(colltodos)
        

        # si cambia coll debe empezar a evaluar nuevamente todos los polígonos
        if numpoliant != numpoli:
            cott = 0
            cortaditas = 0
        
        if Salidita == 1:
            puedo=True
            break
            

    if contadorcito==0:
        puedo=False
        Salidita==1
        colltodoscombi=[]
        colltodoscombi=colltodos.copy()        

if Salidita == 1:
    #print("EXITO")
    pass