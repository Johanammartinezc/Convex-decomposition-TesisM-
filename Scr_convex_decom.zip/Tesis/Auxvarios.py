# -*- coding: utf-8 -*-
"""
Created on Mon Mar 13 13:04:52 2023

@author: jm.martinezc1
"""

import os
import tkinter as tk
from tkinter import filedialog
import io
global aordenar,archivonum
import Graficador


aordenar=1
archivonum=50

#from Graficador import* 


