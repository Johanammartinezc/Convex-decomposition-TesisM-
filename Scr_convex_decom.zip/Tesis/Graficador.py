# -*- coding: utf-8 -*-
"""
Created on Fri Mar  3 15:43:12 2023

@author: jm.martinezc1
"""
#Graficador
import time

import FuncionesN
import Funciones
#from Leertxt_caract import *
import numpy as np
import math
import sys
import Leertxt_caract
#from ayudaorden import *
import Auxvarios
iniciot=time.time()
vertices,lineas,collnotches,lista0,angulito,filas,x,y,convenoconve,sentiang,opuesto=Leertxt_caract.leertxt(Auxvarios.aordenar,Auxvarios.archivonum)
#Gráfica original
from SCcompletanuevo import *
fint=time.time()
import matplotlib.pyplot as plt


tiempo=fint-iniciot


# Datos original---------------------
#Creo listas
x = x
y = y
# Crear un gráfico de dispersión
plt.figure(figsize=(10, 6))
plt.scatter(x, y)
plt.plot(x, y)

# Agregar etiquetas de eje y título
plt.xlabel('Eje X')
plt.ylabel('Eje Y')
plt.title('Gráfico de Dispersión 1.2')
lolo=list(range(0,filas-1))

for i in range(0,len(x)-1):
   plt.annotate(str(lolo[i]), xy=(x[i], y[i]), ha='center', va='bottom')

#quito el útimo

matrizA=[]
for aree in range(0,len(colltodos)):
    finalarea=Funciones.AREAA(aree, x, y, colltodos)
    matrizA.append(finalarea)
    
sumita=sum(matrizA)
#Área total
colltodos.append(lista0)

areatotal=Funciones.AREAA(-1, x, y, colltodos)
print(areatotal,sumita,sumita-areatotal)
if sumita==areatotal:
    print("FIN PERFECTO", len(colltodos)-1,tiempo)
elif sumita<areatotal:
    print("faltan partes")
else:
    print("sobreposición",sumita-areatotal)

##Agrefo una serie de datos para observar las demás
x2=[]
y2=[]
cantidadpoli=len(colltodos)
for amostrar in range(0,cantidadpoli-1):   
    cantidadver=len(colltodos[amostrar])
    for i in range(0,cantidadver+2):
        if i==cantidadver:
            x2.append(vertices[colltodos[amostrar][0]].x)
            y2.append(vertices[colltodos[amostrar][0]].y)
        elif i==cantidadver+1:
            x2.append(None)
            y2.append(None)           
        else:
            x2.append(vertices[colltodos[amostrar][i]].x)
            y2.append(vertices[colltodos[amostrar][i]].y)
        
    plt.scatter(x2, y2)
    plt.plot(x2, y2)

#coloco etiquetas de datos



# Mostrar el gráfico
plt.show()




