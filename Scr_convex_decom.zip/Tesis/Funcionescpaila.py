# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 19:05:25 2023

@author: jm.martinezc1
"""
#IMPORTACIONES
#import Leertxt_caract
import math
import numpy as np
import sys


#F1_ Halla los valores ABC para dos puntos
global A
global B
global C
def recta2(ax,ay,bx,by):
    A=by-ay
    B=-(bx-ax)
    C=A*(-ax)-B*(ay)
    return A,B,C

#Función que normaliza ABC
def normalizarABC(ax,ay,bx,by,normita):
    A,B,C=recta2(ax,ay,bx,by)
    An=A/normita
    Bn=B/normita
    Cn=An*(-ax)-Bn*(ay)
    return An,Bn,Cn

#Función que normaliza los puntos de origen
def normalizarxori(ax,ay,bx,by,normita):
    if normita==0:
        Xorin=0
        Yorin=0
    else:
        Xorin=(bx-ax)/normita
        Yorin=(by-ay)/normita
    return Xorin,Yorin

#Función oara hallar el sentido de la recta
def sentidor(ax,ay,bx,by,A,B):
    if B!=0 and A!=0:
        m=-A/B
        if m>0:
            if by-ay<0 and bx-ax<0:
                srr="SUROESTE"
            else:
                srr="NORESTE"
        else:
            if by-ay<0:
                srr="SURESTE"
            else:
                srr="NOROESTE"
    elif B==0:
        if  bx>ax:
            srr="ESTE"
        else:
            srr="OESTE"
    else:
        if by>ay:
            srr="NORTE"
        else:
            srr="SUR"
    return srr
  
#Función que halla la posición de un punto respecto a una recta  
def puntoenrecta(coefxA,coefyB,coefC,pevax,pevay):
    resultado=coefxA*pevax+coefyB*pevay+coefC
    if resultado>0:
        resultadi="DERECHA"
    elif resultado<0:
        resultadi="IZQ"
    else:
         resultadi="EN RECTA"
    return resultadi

def angulo2(coorx1,coory1,coorx2,coory2):
    pin=math.pi
    if coorx1==-coorx2 and coory1==-coory2:
        angulotetha=180
    elif coorx1==coorx2  and coory1==coory2:
        angulotetha=0
    else:
        angulotetha=math.acos(coorx1*coorx2+coory1*coory2)*180/pin
    return angulotetha

#hallar ángulos de una figura    
def angulosfigura(figura,x,y,vertices):
    angulosayuda=[]
    convexcont=0
    j=0
    coni=0
    conii=0
    vertice_actual=0

    for j in range(0,len(figura)-1):
        #vertice_actual=vertices[figura[j]]
        #vertice_siguiente=vertices[figura[j]]
        if j==0:
            ax=vertices[figura[-2]].x
            ay=vertices[figura[-2]].y
            bx=vertices[figura[0]].x
            by=vertices[figura[0]].y
            pevax=vertices[figura[1]].x
            pevay=vertices[figura[1]].y
        elif j==len(figura)-2:
            ax=vertices[figura[j-1]].x
            ay=vertices[figura[j-1]].y
            bx=vertices[figura[j]].x
            by=vertices[figura[j]].y
            pevax=vertices[figura[0]].x
            pevay=vertices[figura[0]].y
        else:
            ax=vertices[figura[j-1]].x
            ay=vertices[figura[j-1]].y
            bx=vertices[figura[j]].x
            by=vertices[figura[j]].y
            pevax=vertices[figura[j+1]].x
            pevay=vertices[figura[j+1]].y
        A,B,C=recta2(ax, ay, bx, by)
        resultadi=puntoenrecta(A, B, C, pevax, pevay)
        normita=np.sqrt(((ax-bx)**2)+((ay-by)**2))
        xxxori,yyyori=normalizarxori(ax, ay, bx, by, normita)
        normita=np.sqrt(((bx-pevax)**2)+((by-pevay)**2))
        xxori,yyori=normalizarxori(bx, by, pevax, pevay, normita)
        angulotetha=angulo2(xxxori, yyyori, xxori, yyori) #muere acá
        if resultadi=="IZQ": #ERROR no está entrando
            angulosayuda.append(180-angulotetha)
            coni=coni+1
            #print("holi")
        else:
            angulosayuda.append(180+angulotetha)
            conii=conii+1
        
    #recorro la creo
    for tu in range(0,len(angulosayuda)):
        if angulosayuda[tu]>180:
            convexcont=1
            break
        else:
            pass
    return angulosayuda,convexcont
    
#Función que evalúa si hay pntos dentro de la figura
def puntosdentro(lista0,figura,x,y,filas,vertices):
    ira = 0
    print(figura)
    for kf in range(filas - 1):
        pevax = vertices[lista0[kf]].x
        pevay = vertices[lista0[kf]].y
        KK = 0
        for jf in range(len(figura)):
            p1 = figura[jf - 1]
            ax = vertices[figura[jf - 1]].x
            ay = vertices[figura[jf - 1]].y
            if jf == 0:
                bx = vertices[figura[0]].x
                by = vertices[figura[0]].y
                p2 = figura[0]
            elif jf == len(figura):
                bx = vertices[figura[-1]].x
                by = vertices[figura[-1]].y
                p2 = figura[-1]
            else:
                bx = vertices[figura[jf]].x
                by = vertices[figura[jf]].y
                p2 = figura[jf]
            A, B, C = recta2(ax, ay, bx, by)
            if lista0[kf] == p1 or lista0[kf] == p2:
                continue
            else:
                resultadi = puntoenrecta(A, B, C, pevax, pevay)
            if resultadi == "IZQ" or resultadi == "EN RECTA":
                KK = KK + 1 
        if KK == len(figura):
            ira = 1
            break
        else:
            KK = 0
    return ira

#Procedimiento de cortar
def cortedelcorte(v3,v1,figurares,x,y,angulosmayuda,colltodos,vertices):
    salir2=0
    collp=[]
    Pfinal=v3
    Pinicialposi=figurares.index(v1)
    Pfinalposi=figurares.index(v3)
    if Pinicialposi>Pfinalposi:
        for jj in range(Pinicialposi,len(figurares)):
            collp.append(figurares[jj])
        for jj in range(0,Pfinalposi):
            collp.append(figurares[jj])
    else:
        for jj in range(Pinicialposi,Pfinalposi+1):
            collp.append(figurares[jj])
    #agrego collp
    colltodos.append(collp)
    
    #redimensiono P
    for jj in range(1,len(collp)-1):
        figurares.remove(collp[jj])
        angulosmayuda,convexcont=angulosfigura(figurares, x, y,vertices)
        mm= False
        #colltodos.append(collp)
        if len(figurares)==3 or convexcont==0:
            Peta=False
            salir2=1
            #Exit function
    
    mm=False
    Pinicial=0
    return figurares,angulosmayuda,Pinicial,collp,salir2,mm
                

def evaang2(v2,angulosmayuda,P,corte,Pinicial,mm,salir):
    if corte != 0:
        lll = len(collp)
        posienpp=P.index(collp[lll])  # busco en P el último item de collp
        if posienpp == 2:
            lml = 1

    posienpp=P.index(v2)
    if angulosmayuda[posienpp] > 180:  # If angulito(V(2)) >= 180 Then ''''30/01
        Pinicial += 1
        mm = False
        salir = 1
    return Pinicial,mm,salir



def evaant(v3,P,angulos,v2,Pinicial,cambiocam,irnocorte,lml,v1):
    posienpp=P.index(v3)
    if posienpp==0:
        posienpp=len(P)+1
    if angulos[posienpp-1]>180:
        posienpp=P.index(P[posienpp-1])
        if posienpp==0:
            pass
        else:
            irnocorte=1
    elif angulos[posienpp-1]>180 and P.index(P[posienpp-1])==v2:
        if lml!=1:
            posienpp=P.index(v1)
            Pinicial=posienpp+1
            cambiocam=1
    return Pinicial,cambiocam,irnocorte

def evaangvec2(x, y, V,vertices):
    vectoraiuda = []
    #plp = 0
    i=0
    for i in range(0, 2):
        ax = vertices[V[0][i]-1].x
        ay = vertices[V[0][i]-1].y
        bx = vertices[V[0][i+1]-1].x
        by = vertices[V[0][i+1]-1].y
        #print(V[0][i],V[0][i+1])
        normita = np.sqrt(((ax-bx)**2)+((ay-by)**2))
        Xorin,Yorin=normalizarxori(ax, ay, bx, by, normita)  
        vectoraiuda.append(Xorin)
        vectoraiuda.append(Yorin)
        #plp = plp+1
        
    #plp = 2
    #print(vectoraiuda)
    angulotetha =angulo2(vectoraiuda[0], vectoraiuda[1], vectoraiuda[2], vectoraiuda[3])
    ircorte = 0
    if angulotetha <= 180:
        pass
    else:
        ircorte = 1
    return ircorte


def cortarr(acortar,P):
    #quitar los puntos de p
    i=0
    for i in range(1,len(acortar)-1):
        P.remove(acortar[i])
    return P
    
def escogervert(Pinicial,P,V):
    entradaprin = 0
    try:
        V[0][0] = P[Pinicial]
    except:
        print(Pinicial)
    if Pinicial + 1 > len(P) - 1: # 21/02 se agregó esta condición
        Pinicial = 0
        Pinicial += 1
        entradaprin = 1
        V[0][1] = P[Pinicial]
    else:
        V[0][1] = P[Pinicial + 1]
    if V[0][1] == P[-1]:
        V[0][2] = P[0]
    elif entradaprin == 1:
        V[0][2] = P[Pinicial + 1]
    else:
        V[0][2] = P[Pinicial + 2]
        
    if V[0][0] == P[-1]:
        V[0][1] = P[0]
        #V[0][2] = P[1] # 21/02 se cambió de 1 a P(1)
    
# para 612
    if V[0][0] == P[-1]:
        V[0][0] = V[0][0]
        V[0][1] = P[0]
        V[0][2] = P[1]
        Pinicial = 1


    AAAA = P[1]
    LL = 0
    return V[0][0],V[0][1],V[0][2],LL
 
def angulofinalini(V,x,y,P,vertices):
    vectoraiudaa = []
    eeuu=0
    for i in range(0, 2):
        if i == 1:
            ax = vertices[V[0][2]].x
            ay = vertices[V[0][2]].y
            bx = vertices[V[0][0]].x
            by = vertices[V[0][0]].y
        else:
            ax = vertices[V[0][i]].x
            ay = vertices[V[0][i]].y
            bx = vertices[V[0][i+1]].x
            by = vertices[V[0][i+1]].y
    
        # have the first vector
        normita = ((ax - bx) ** 2 + (ay - by) ** 2) ** 0.5
        A,B,C=recta2(ax, ay, bx, by)
        Xorin,Yorin=normalizarxori(ax, ay, bx, by,normita)
        vectoraiudaa.append(Xorin)
        vectoraiudaa.append(Yorin)
        srr=sentidor(ax, ay, bx, by,A,B)
        vectoraiudaa.append(srr)
        #plp += 2
    
        # see where the last point is relative to the first line
        if i == 0:
            A,B,C=recta2(ax, ay, bx, by)
            resultadi=puntoenrecta(A, B, C, vertices[V[0][2]-1].x,vertices[V[0][2]-1].y )
    
    #ooo = pp
    #plp = 0
    #print(vectoraiudaa+"hola")
    angulotetha=angulo2(vectoraiudaa[0], vectoraiudaa[1], vectoraiudaa[3], vectoraiudaa[4])  # 16/02 changed last two f to e and last two to 4 and 5 from 3 and 4
    posienpp=P.index(V[0][0])
    
    if resultadi != "DERECHA":
        angg=combisentidos(vectoraiudaa[5], vectoraiudaa[2],angulotetha)  # 07/02 (3) and (6)
    
    # combisentidos(vectoraiudaa[6], vectoraiudaa[3])  # 07/02 (3) and (6)
    if resultadi == "DERECHA":  # 24/02 added this if
        angg = 360 - angulotetha
        if angg >= 180:  # 07/02 added condition for equality
            # if the vector is south and the point is to the right
            # return and exit
            if resultadi == "DERECHA":
                eeuu = 1
                #exit()
    return eeuu
            
            
def combisentidos(sen1,sen2,angulotetha):
    angg=0
    if sen1 == "NORESTE" and sen2 == "ESTE":
        angg = 180 + angulotetha
    elif sen1 == "NORESTE" and sen2 == "NORTE":
        angg = 180 - angulotetha
    elif sen1 == "ESTE" and sen2 == "NOROESTE":
        angg = 180 - angulotetha
    elif sen1 == "ESTE" and sen2 == "NORTE":
        angg = angulotetha
    elif sen1 == "NORTE" and sen2 == "OESTE":
        angg = angulotetha
    elif sen1 == "OESTE" and sen2 == "SURESTE":
        angg = 180 - angulotetha
    elif sen1 == "OESTE" and sen2 == "SUR":
        angg = angulotetha
    elif sen1 == "SUROESTE" and sen2 == "SUR":
        angg = angulotetha
    elif sen1 == "SUROESTE" and sen2 == "OESTE":
        angg = 180 + angulotetha
    elif sen1 == "NORESTE" and sen2 == "OESTE":
        angg = 180 - angulotetha
    elif sen1 == "NORESTE" and sen2 == "SURESTE":
        angg = 180 + angulotetha
    elif sen1 == "SUR" and sen2 == "ESTE":
        angg = angulotetha
    elif sen1 == "SUR" and sen2 == "NOROESTE":
        angg = 360 - angulotetha
    elif sen1 == "SURESTE" and sen2 == "NORESTE":
        angg = angulotetha
    elif sen1 == "ESTE" and sen2 == "SUR":
        angg = 360 - angulotetha
    elif sen1 == "SURESTE" and sen2 == "NOROESTE":
        angg = 180 - angulotetha
    elif sen1 == "SURESTE" and sen2 == "ESTE":
        angg = 180 + angulotetha
    elif sen1 == "SUR" and sen2 == "NORESTE":
        angg = 180 - angulotetha
    elif sen1 == "SURESTE" and sen2 == "SURESTE":
        angg = 360 - angulotetha
    elif sen1 == "OESTE" and sen2 == "SUROESTE":
        angg = 180 - angulotetha
    elif sen1 == "SURESTE" and sen2 == "SUR":
        angg = 180 + angulotetha
    return angg

def nocorteee(P,V3,Pinicial,V,LUCKYS):
    mm=True
    posienpp=P.index(V[0][2])##
    if LUCKYS==1:
        V[0][2]=V[0][2]
    else:
        if posienpp==0:
            V[0][2]=P[-1]
        else:
            V[0][2] = P[posienpp - 1]
    # evalúo que no esté en el comienzo
    if V[0][2] == V[0][1]:
        Pinicial = Pinicial + 1
        mm = False
    return Pinicial,mm,V[0][2]

def corteee(V3,V1,P,Pinicial,V,corte,colltodos,x,y,Peta):
    # CORTE//////////////////////////////////////////////
    Pfinal = V3  # sé cual es el punto final de corte
    # hago la lista del collection
    collp = []
    # ciclo números del corte
    # busco el Pinicial en la lista de P
    posienpp=P.index(V1)
    Pinicialposi = posienpp
    posienpp=P.index(V3)
    Pfinalposi = posienpp
    #print(V3,V1,5000)
    # hago ciclo
    for jj in range(Pinicialposi, Pfinalposi + 1):
        collp.append(P[jj])
    
    
    # Redimensiono P (corto la figura)
    elementoscoll = len(collp)
    nvmax = len(P)
    nuevadimen = nvmax - (elementoscoll - 2)
    #P = [0] * nuevadimen
    
    # vértices de la figura P restante
    for i in range(1, Pinicial + 1):
        P[i - 1] = i
    if V[0][1] == Pinicial:
        P[Pinicial] = V[0][2]
    else:
        P[1] = collp[0]
    for j in range(Pinicial + 2, nuevadimen + 1):
        if nuevadimen == 3:
            milo = len(collp)
            P[j - 1] = collp[milo - 1]
        else:
            P[j - 1] = P[j - 2] + 1
    # sale
    
    mm = False
    # Cuento cortes
    corte += 1
    
    # en el momento que haga el corte agrego la lista
    colltodos.append(collp)
    
    convexcont = 0
    # evalúo si en la figura restante P' hay notches
    # tengo que saber si el notche que metí en el corte está en p y coger el siguiente
    angulosmayuda,convexcont=angulosfigura(P,x,y)
    # TENG QUE EVALUAR EL OTRO NOTCH
    # evaluar notche
    lll = len(collp)
    posienpp=P.index(collp[lll - 1])
    #print(len(P)+50000)
    for i in range(posienpp + 1-1, nuevadimen + 1-1):
        if angulosmayuda[P[i - 1]] >= 180:
            convexcont = 1
    if convexcont==0:
        Peta=False
        salir2=1
    # evalúo ángulo vectores en vez de notch
    # donde esté el punto final -1
    return P, angulosmayuda,convexcont,mm,Peta,salir2

        
def crearfigura(v3,v1,figurares,x,y):
    collp=[]
    Pfinal=v3
    Pinicialposi=figurares.index(v1)
    Pfinalposi=figurares.index(v3)
    if Pinicialposi>Pfinalposi:
        for jj in range(Pinicialposi,len(figurares)):
            collp.append(figurares[jj])
        for jj in range(0,Pfinalposi):
            collp.append(figurares[jj])
    else:
        for jj in range(Pinicialposi,Pfinalposi+1):
            collp.append(figurares[jj])
    return collp

def elegirxy(numeleini,colltodos,cott,fi):
    ultimaiter=0
    if fi==numeleini-1:##
        parrx=colltodos[cott][0]       
        parry=colltodos[cott][-1]
        ultimaiter=1
    else:
        parrx=colltodos[cott][fi]
        parry=colltodos[cott][fi+1]    
    return parrx,parry,ultimaiter

def evaluarenpoli(numele,cott,colltodos,parrx,parry,k,collpoli,contadorr):
    defix=0
    defiy=0
    rompe=0
    for u in range(0,numele-1):
        if k==cott:
            rompe=1
            break
        else:
            if (parrx==colltodos[k][u]) and (parry==colltodos[k][u+1]):
                contadorr=contadorr+1
                collpoli.append(k)
                defix=parrx
                defiy=parry
            elif (parrx==colltodos[k][1]) and (parry==colltodos[k][numele-1]):
                contadorr=contadorr+1
                collpoli.append(k)
                defix=parrx
                defiy=parry
                break
    return collpoli,contadorr,rompe

def definirrectas(collpoli,parrx,parry,colltodos,x,y,qq,quitar,paila,vertices):
    Poli1 = collpoli[0]
    mABCevapoli = np.zeros((5, 3))

    
    #for i in range(4):
     #   mABCevapoli.append([0] * 3)
    
    # matriz que guarda ABC rectas

    # auxiliares para las condiciones de las rectas
    condii = [0] * 8
    choco=0
    saltesee=False
    for choco in range(0, 5):
        if condii[0] == 0 and saltesee==False:
            if (colltodos[Poli1][0] == parrx and colltodos[Poli1][1] == parry):
                # línea ÚLTI-PRIMERO
                ulti = colltodos[Poli1][-1]
                A,B,C=recta2(vertices[ulti].x, vertices[ulti].y, vertices[parrx].x, vertices[parrx].y)##HELP
                # cambio el condi para que no evalúe en la siguiente iter

                condii[0] = 1
                # me salgo
                saltesee=True
                #break
    
        if condii[1] == 0 and saltesee==False:
            if (colltodos[Poli1][0] == parrx and colltodos[Poli1][1] != parry):
                # línea
                # Debug.Print colltodos[Poli1][2]
                # Call pruebaconALGO2
                A,B,C=recta2(vertices[parrx].x, vertices[parrx].y, x[colltodos[Poli1][1]], y[colltodos[Poli1][2]])
                # cambio el condi para que no evalúe en la siguiente iter
                condii[1] = 1
                saltesee=True
                # me salgo
                #break
    
        if condii[2] == 0 and saltesee==False:
            if (colltodos[Poli1][-1] == parrx and colltodos[Poli1][-2] != parry):
                # línea
                ayuayu = colltodos[Poli1][-2]
                A,B,C=recta2(vertices[ayuayu].x, vertices[ayuayu].y, vertices[parrx].x, vertices[parrx].y)
                # cambio el condi para que no evalúe en la siguiente iter
                condii[2] = 1
                # me salgo
                saltesee=True
                #break
    
        if condii[3] == 0 and saltesee==False:
            if (colltodos[Poli1][-1]) == parrx and (colltodos[Poli1][-2]== parry):
                # línea
                ayuayu = colltodos[Poli1][-1]
                A,B,C=recta2(vertices[parrx].x, vertices[parrx].y, x[colltodos[Poli1][1]], y[colltodos[Poli1][1]])
                # cambio el condi para que no evalúe en la siguiente iter
                condii[3] = 1
                # me salgo
                saltesee=True
                #break
    
        if condii[4] == 0 and saltesee==False:
            if colltodos[Poli1][0] != parry and colltodos[Poli1][-1] != parry:
                # find position
                for m in range(0, len(colltodos[Poli1]) + 1):
                    if parry == colltodos[Poli1][m]:
                        break
                if colltodos[Poli1][m - 1] == parrx:
                    # ABC posix posix+1
                    ayuayu = colltodos[Poli1][m+1]
                    A,B,C=recta2(vertices[parry].x, vertices[parry].y, vertices[ayuayu].x, vertices[ayuayu].y)
                elif colltodos[Poli1][m+1] == parrx:
                    # ABC posix-1 posix
                    ayuayu = colltodos[Poli1][m-1]
                    A,B,C=recta2(vertices[ayuayu].x, vertices[ayuayu].y, vertices[parry].x, vertices[parry].y)
                # change condi so it won't be evaluated in the next iteration
                condii[4] = 1
                # exit
                saltesee=True
                #break
        
        if condii[5] == 0 and saltesee==False:
            if colltodos[Poli1][-1] == parry and colltodos[Poli1][len(colltodos[Poli1]) - 1] != parrx:
                # line
                ayuayu = colltodos[Poli1][-2]
                A,B,C=recta2(vertices[ayuayu].x, vertices[ayuayu].y, vertices[parry].x, vertices[parry].y)
                # change condi so it won't be evaluated in the next iteration
                condii[5] = 1
                # exit
                saltesee=True
                #break
        
        if condii[6] == 0 and saltesee==False:
            if colltodos[Poli1][-1] == parry and colltodos[Poli1][-2] == parrx:
                # line
                ayuayu = colltodos[Poli1][0]
                A,B,C=recta2(vertices[parry].x, vertices[parry].y, vertices[ayuayu].x, vertices[ayuayu].y)
                # change condi so it won't be evaluated in the next iteration
                condii[6] = 1
                # exit
                saltesee=True
                #break
        
        if condii[7] == 0 and saltesee==False:
            if colltodos[Poli1][0] != parrx and colltodos[Poli1][-1] != parrx:
                # find position
                for m in range(0, len(colltodos[Poli1]) + 1):
                    if parrx == colltodos[Poli1][m]:
                        break
                if colltodos[Poli1][m-1] == parry:
                    # ABC posix posix+1
                    ayuayu = colltodos[Poli1][m+1]
                    A,B,C=recta2(vertices[parrx].x, vertices[parrx].y, vertices[ayuayu].x, vertices[ayuayu].y)
                elif colltodos[Poli1][m+1] == parry:
                    # ABC posix-1 posix
                    ayuayu=colltodos[Poli1][m-1]
                    A,B,C=recta2(vertices[ayuayu].x,vertices[ayuayu].y,vertices[parrx].x,vertices[parrx].y)
                condii[7]=1
                saltesee=True
                #break
    # registrando en matriz
        mABCevapoli[choco][0] = A
        mABCevapoli[choco][1] = B
        mABCevapoli[choco][2] = C
    # llamo a la función de evaluar los puntos del otro poli
        saltesee=False
        paila = 0

        paila=evaluapuntospoli(collpoli,colltodos,Poli1,x,y,A,B,C,paila)

        if paila == 1:
        # No se puede cortar
            quitar = 0
        # debe salirse porque para qué sigue evaluando
            return Poli1,quitar,paila,qq
        else:
            # Se puede quitar
            qq += 1
            quitar = 1
    
        paila = 0
        #paila=evaluapuntospoli(collpoli,colltodos,Poli1,x,y,A,B,C,paila)
        if choco >= 2-1:
            Poli1 = collpoli[1]

    return Poli1,quitar,paila,qq

def evaluapuntospoli(collpoli,colltodos,Poli1,x,y,A,B,C,paila,vertices):
    # evalúo cuál es el polígono de los puntos a evaluar

    for iind in range(0, len(collpoli)+1):
        if Poli1 != collpoli[iind]:
            Polieva = collpoli[iind]

            break
    

    # una vez sepa el polígono evalúo todos en la recta
    for jff in range(0, len(colltodos[Polieva])-1):
        ax = vertices[colltodos[Polieva][jff]].x
        ay = vertices[colltodos[Polieva][jff]].y
        

        
        resultadi=puntoenrecta(A, B, C,ax, ay)
        if resultadi == "DERECHA":
            paila = 1
            break # si alguno da derecha, sálgase y no evalúe más
    return paila

def quitaryponer(collpoli,colltodos,collnuevo):
    # quito los polígonos unidos
    # hago una copia
    #print("ESTA COPIA")
    copiaa = []
    copiaa=collpoli.copy()
        
    # primero debo organizar collpoli:organizo la copia
    for i in range(0, len(collpoli)):
        for j in range(i + 1, len(collpoli)):
            if copiaa[i] > copiaa[j]:
                veve = copiaa[i]
                copiaa[i] = copiaa[j]
                copiaa[j] = veve
    
    # dimensiono de nuevo collpoli ordenado
    collpoli = []
    collpoli=copiaa.copy()

    for i in range(len(collpoli)-1, 0, -1):
        aquitar = collpoli[i]
        #try:
         #   colltodos.remove(aquitar)
        #except:
          #  print("aqui:",len(collpoli),"lon",len(colltodos),colltodos,aquitar)
    # agregar el nuevo
    colltodos.append(collnuevo)
    
    # limpio collpoli
    collpoli = []

    return colltodos 
    
    
def nuevopoli(collpoli,colltodos,ccc,ere):
    collayuda = []
    collnuevo = []
    
    s1 = len(colltodos[collpoli[0]])
    s2 = len(colltodos[collpoli[1]])

    for i in range(0,2):
        for j in range(len(colltodos[collpoli[i]])):
            acolocar = colltodos[collpoli[i]][j]
            collayuda.append(acolocar)


    sumita=s1+s2 
    matrizayucoll=[]
    #matrizayucoll = [collayuda[i] for i in range(len(collayuda))]
    matrizayucoll=collayuda.copy()
    #for ij in range(0,sumita):
     #   matrizayucoll.append(collayuda[ij])

    # Ordenar de menor a mayor
    matrizayucoll.sort()

    # Añadir elementos únicos a collnuevo
    collnuevo=matrizayucoll.copy()
   
    # Eliminar duplicados
    collnuevo=list(set(matrizayucoll))
    collnuevo.sort()
    
    
    
    # Agregar a colltodos
    colltodos.pop(collpoli[0])
    colltodos.pop(collpoli[1])
    colltodos.append(collnuevo)
    #if s1==3 and s2==3:
      #  print("ayuda",collayuda,matrizayucoll,collnuevo,len(colltodos))
       # exit() 

    return colltodos,collpoli,collnuevo
    
def AREAA(parameterr,x,y,colltodos,vertices):
    # conteo vértices
    conteover = len(colltodos[parameterr])
    # multiplico coordenadas
    sum1, sum2 = 0, 0
    for i in range(0, conteover):
        if i == conteover-1:
            verti = colltodos[parameterr][i]
            sum1 = vertices[verti].x * vertices[colltodos[parameterr][0]].y + sum1
            sum2 = vertices[colltodos[parameterr][0]].x * vertices[verti].y + sum2
        else:
            verti = colltodos[parameterr][i]
            sum1 = vertices[verti].x * vertices[colltodos[parameterr][i+1]].y + sum1
            sum2 = x[colltodos[parameterr][i+1]] * vertices[verti].y + sum2

    
    finalarea = 1/2 * abs(sum1 - sum2)
    return finalarea 






