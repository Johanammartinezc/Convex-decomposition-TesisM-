# -*- coding: utf-8 -*-
"""
Created on Sat Mar  4 09:32:35 2023

@author: jm.martinezc1
"""
import Funciones
from Leertxt_caract import *
import numpy as np
import math

P=[]
P=lista0.copy()
angulosmayuda=[]
angulosmayuda=angulito.copy()
j=0
V=[[0,0,0]]
hh=0
colltodos=[]

for ru in range(0, len(collnotches)-1):
    # compruebo que el inmediatamente siguiente no sea notche
    # posición
    estoyenul = 0
    posienpp=P.index(collnotches[ru])
    if ru == len(collnotches):
        doblea = 1-1
        dobleb = posienpp - 1-1
        estoyenul = 1
    else:
        doblea = ru + 1
        dobleb = posienpp + 1
    
    # compruebo que el siguiente no sea el consecutivo
    #try:
    j=0
    if collnotches[doblea] == P[dobleb]:
        j += 1
        # exit for
    else:
        p1 = collnotches[ru]
        if estoyenul == 1:
            p2 = collnotches[0]
        else:
            p2 = collnotches[ru + 1]
        
        if j == 0:
            # hago la figura
            posienpp=P.index(p1)
            inicio = posienpp
            posienpp=P.index(p2)
            fin = posienpp
            # si tiene que darle la vuelta al vector
            if inicio > fin:
                dobley = inicio
                inicio = fin
                fin = dobley
            
            collcreo = []
            for xz in range(inicio, fin + 1):
                collcreo.append(P[xz])

            # Evalúo los ángulos
            angulosmayuda,convexcont=Funciones.angulosfigura(collcreo,x,y,vertices)
            # evaluar si hay puntos dentro
            V[0][0] = p1
            V[0][2] = p2
            ira = 0
            ira=Funciones.puntosdentro(lista0,collcreo,x,y,filas,vertices) #ARREGLAR
            # si hay puntos dentro pase a la siguiente iter
            if ira != 1:
                sali = 0
                for tu in range(len(angulosmayuda)):
                    if angulosmayuda[tu] > 180:
                        sali = 1
                        break
                
                # si todo bien, corte
                if sali == 0:
                    hh += 1
                    #cortarr()##ARREGLAR
                    P=Funciones.cortarr(collcreo, P)
                    angulosmayuda,convexcont=Funciones.angulosfigura(P,x,y,vertices)
                   #Agrego a la lista collcreo
                   # En el momento que haga el corte agrego la lista
                    colltodos.append(collcreo)
                    #convexcont = 0

                    for i in range(1, len(angulosmayuda)):
                        if angulosmayuda[i] > 180:
                            convexcont = 1
                    convexcont=0
                    # Si nuevadimen 3 ya pare
                    nuevadimen=len(P)
                    if nuevadimen == 3:
                        Peta = False
                        salir2 = 1
                        # break

                    collpepe = []
                    for i in range(1, len(P)):
                        creadopepe = 1
                        collpepe.append(P[i])               
                   
                #si está bien la restante tiene que salirse                  
                if len(collnotches) == 2:
                    ru += 1
        j = 0

    if hh == 0:
        # si no hubo ningún corte evalúe P igual
        angulosmayuda,convexcont=Funciones.angulosfigura(collcreo,x,y,vertices) #ARRREGLAR
    #except:
     #   print(doblea,dobleb)
